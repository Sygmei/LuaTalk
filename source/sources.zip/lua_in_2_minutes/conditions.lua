local a = {1, 2, 3};

-- Notice the fact that usual brackets are remplaced by "then" and "end"
if a[2] > 2 then
    print("Bonjour");
elseif a[2] < 0 then
    print("Au revoir");
else
    print("Bonsoir");
end