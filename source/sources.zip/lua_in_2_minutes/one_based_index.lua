local a = {1, 2, 3}; -- Creating a new table with 3 numbers inside
print(a[2]); -- Will print 2 because Lua is 1-based