local a = 1;
local b = 2;
print(a == b); -- Equality test
print(a ~= b); -- Non-equality test, it's not the usual !=
print(a > b); -- More-than test
print(a < b); -- Less-than test
print(a >= b); -- More-or-equal test
print(a <= b); -- Less-or-equal test