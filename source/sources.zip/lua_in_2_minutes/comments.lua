local a = 1; -- A comment
--[[ A multiline
comment that takes a lot
of space :)
]]