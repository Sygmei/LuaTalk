table_var = {}; -- A Lua table acts as a list / dictionnary
string_var = "Bonjour";
number_int_var = 42; -- type is number
number_var = 3.14 -- type is also number
bool_var = true;
nil_var = nil;
func_var = function() end;
thread_var = coroutine.create(func_var);